"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Calendar, Wheat, DollarSign, Clock, Droplets, ArrowLeft } from "lucide-react"
import Link from "next/link"
import { useSearchParams } from "next/navigation"

const crops = [
  {
    id: "wheat",
    name: "Wheat",
    season: "Rabi",
    sowingMonths: ["November", "December"],
    harvestMonths: ["April", "May"],
    duration: "120-150 days",
    expectedYield: "18-25 quintals/acre",
    profitMargin: "₹25,000-35,000",
    waterRequirement: "Medium",
    fertilizers: [
      { stage: "Sowing", fertilizer: "DAP", quantity: "50 kg/acre", timing: "At sowing" },
      { stage: "Tillering", fertilizer: "Urea", quantity: "25 kg/acre", timing: "20-25 days after sowing" },
      { stage: "Flowering", fertilizer: "Urea", quantity: "25 kg/acre", timing: "45-50 days after sowing" },
    ],
  },
  {
    id: "bajra",
    name: "Bajra (Pearl Millet)",
    season: "Kharif",
    sowingMonths: ["June", "July"],
    harvestMonths: ["September", "October"],
    duration: "75-90 days",
    expectedYield: "15-20 quintals/acre",
    profitMargin: "₹20,000-30,000",
    waterRequirement: "Low",
    fertilizers: [
      { stage: "Sowing", fertilizer: "DAP", quantity: "40 kg/acre", timing: "At sowing" },
      { stage: "Growth", fertilizer: "Urea", quantity: "30 kg/acre", timing: "30 days after sowing" },
    ],
  },
  {
    id: "cotton",
    name: "Cotton",
    season: "Kharif",
    sowingMonths: ["May", "June"],
    harvestMonths: ["October", "November", "December"],
    duration: "180-200 days",
    expectedYield: "8-12 quintals/acre",
    profitMargin: "₹40,000-60,000",
    waterRequirement: "High",
    fertilizers: [
      { stage: "Sowing", fertilizer: "DAP", quantity: "60 kg/acre", timing: "At sowing" },
      { stage: "Squaring", fertilizer: "Urea", quantity: "40 kg/acre", timing: "45 days after sowing" },
      { stage: "Flowering", fertilizer: "MOP", quantity: "30 kg/acre", timing: "75 days after sowing" },
    ],
  },
]

export default function PlantingGuide() {
  const searchParams = useSearchParams()
  const cropFromUrl = searchParams.get("crop")
  const [selectedCrop, setSelectedCrop] = useState(crops[0])

  useEffect(() => {
    if (cropFromUrl) {
      const foundCrop = crops.find((crop) => crop.id === cropFromUrl)
      if (foundCrop) {
        setSelectedCrop(foundCrop)
      }
    }
  }, [cropFromUrl])

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center space-x-4">
            <Link href="/dashboard">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Dashboard
              </Button>
            </Link>
            <div className="flex items-center space-x-2">
              <Calendar className="h-6 w-6 text-green-600" />
              <h1 className="text-2xl font-bold text-green-800">Planting Guide</h1>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {/* Crop Selection */}
        <div className="mb-8">
          <h2 className="text-xl font-semibold mb-4">Select Crop</h2>
          <div className="grid md:grid-cols-3 gap-4">
            {crops.map((crop) => (
              <Card
                key={crop.id}
                className={`cursor-pointer transition-all ${
                  selectedCrop.id === crop.id ? "ring-2 ring-green-500 bg-green-50" : "hover:shadow-md"
                }`}
                onClick={() => setSelectedCrop(crop)}
              >
                <CardContent className="p-4">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="font-semibold">{crop.name}</h3>
                    <Badge variant={crop.season === "Kharif" ? "default" : "secondary"}>{crop.season}</Badge>
                  </div>
                  <div className="text-sm text-gray-600">
                    <div>Sowing: {crop.sowingMonths.join(", ")}</div>
                    <div>Duration: {crop.duration}</div>
                  </div>
                  <Link href={`/planting-guide?crop=${crop.id}`}>
                    <Button size="sm" className="w-full">
                      View Planting Guide
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Detailed Crop Information */}
        <div className="grid lg:grid-cols-3 gap-6 mb-8">
          {/* Overview Card */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Wheat className="h-5 w-5 text-green-600" />
                <span>{selectedCrop.name} Overview</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <div className="text-sm text-gray-600">Season</div>
                <div className="font-medium">{selectedCrop.season}</div>
              </div>
              <div>
                <div className="text-sm text-gray-600">Sowing Period</div>
                <div className="font-medium">{selectedCrop.sowingMonths.join(", ")}</div>
              </div>
              <div>
                <div className="text-sm text-gray-600">Harvest Period</div>
                <div className="font-medium">{selectedCrop.harvestMonths.join(", ")}</div>
              </div>
              <div>
                <div className="text-sm text-gray-600">Duration</div>
                <div className="font-medium flex items-center">
                  <Clock className="h-4 w-4 mr-1" />
                  {selectedCrop.duration}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Yield & Profit Card */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <DollarSign className="h-5 w-5 text-green-600" />
                <span>Yield & Profit</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <div className="text-sm text-gray-600">Expected Yield</div>
                <div className="font-medium text-lg">{selectedCrop.expectedYield}</div>
              </div>
              <div>
                <div className="text-sm text-gray-600">Profit Margin</div>
                <div className="font-medium text-lg text-green-600">{selectedCrop.profitMargin}</div>
              </div>
              <div>
                <div className="text-sm text-gray-600">Water Requirement</div>
                <div className="font-medium flex items-center">
                  <Droplets className="h-4 w-4 mr-1 text-blue-500" />
                  {selectedCrop.waterRequirement}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Quick Tips Card */}
          <Card>
            <CardHeader>
              <CardTitle>Quick Tips</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 text-sm">
                <div className="p-3 bg-blue-50 rounded-lg">
                  <div className="font-medium text-blue-800">Soil Preparation</div>
                  <div className="text-blue-700">Ensure proper field leveling and organic matter incorporation</div>
                </div>
                <div className="p-3 bg-green-50 rounded-lg">
                  <div className="font-medium text-green-800">Seed Treatment</div>
                  <div className="text-green-700">Treat seeds with fungicide before sowing</div>
                </div>
                <div className="p-3 bg-amber-50 rounded-lg">
                  <div className="font-medium text-amber-800">Weather Watch</div>
                  <div className="text-amber-700">Monitor weather conditions for optimal sowing time</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Fertilizer Schedule */}
        <Card>
          <CardHeader>
            <CardTitle>Fertilizer Schedule</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b">
                    <th className="text-left py-3 px-4">Growth Stage</th>
                    <th className="text-left py-3 px-4">Fertilizer</th>
                    <th className="text-left py-3 px-4">Quantity</th>
                    <th className="text-left py-3 px-4">Timing</th>
                  </tr>
                </thead>
                <tbody>
                  {selectedCrop.fertilizers.map((fertilizer, index) => (
                    <tr key={index} className="border-b">
                      <td className="py-3 px-4 font-medium">{fertilizer.stage}</td>
                      <td className="py-3 px-4">{fertilizer.fertilizer}</td>
                      <td className="py-3 px-4">{fertilizer.quantity}</td>
                      <td className="py-3 px-4">{fertilizer.timing}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        {/* Calendar View */}
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>Farming Calendar</CardTitle>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="current" className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="current">Current Season</TabsTrigger>
                <TabsTrigger value="next">Next Season</TabsTrigger>
              </TabsList>
              <TabsContent value="current" className="mt-6">
                <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
                  {["Week 1", "Week 2", "Week 3", "Week 4"].map((week, index) => (
                    <Card key={week}>
                      <CardContent className="p-4">
                        <div className="font-medium mb-2">{week}</div>
                        <div className="text-sm text-gray-600">
                          {index === 0 && "Field preparation & sowing"}
                          {index === 1 && "Irrigation & monitoring"}
                          {index === 2 && "First fertilizer application"}
                          {index === 3 && "Weed management"}
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>
              <TabsContent value="next" className="mt-6">
                <div className="text-center py-8 text-gray-500">
                  Next season planning will be available based on current crop performance
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
