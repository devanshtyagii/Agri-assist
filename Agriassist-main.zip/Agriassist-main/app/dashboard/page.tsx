"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  CloudRain,
  Wheat,
  TrendingUp,
  Lightbulb,
  AlertTriangle,
  Droplets,
  Wind,
  Sun,
  ArrowUp,
  LogOut,
  User,
} from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"

const rainfallData = [
  { day: "Day 1", rainfall: 12 },
  { day: "Day 2", rainfall: 8 },
  { day: "Day 3", rainfall: 15 },
  { day: "Day 4", rainfall: 22 },
  { day: "Day 5", rainfall: 18 },
  { day: "Day 6", rainfall: 5 },
  { day: "Day 7", rainfall: 3 },
  { day: "Day 8", rainfall: 0 },
  { day: "Day 9", rainfall: 7 },
  { day: "Day 10", rainfall: 25 },
]

export default function Dashboard() {
  const [currentTime, setCurrentTime] = useState(new Date())
  const [user, setUser] = useState<any>(null)
  const router = useRouter()

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000)

    // Check authentication
    const userData = localStorage.getItem("agriAssistUser")
    if (!userData) {
      router.push("/auth")
      return
    }

    const parsedUser = JSON.parse(userData)
    if (!parsedUser.isLoggedIn) {
      router.push("/auth")
      return
    }

    setUser(parsedUser)

    return () => clearInterval(timer)
  }, [router])

  const handleLogout = () => {
    localStorage.removeItem("agriAssistUser")
    router.push("/")
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600"></div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-green-50">
      {/* Enhanced Header */}
      <header className="bg-white/80 backdrop-blur-lg shadow-lg border-b border-green-100">
        <div className="container mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-4">
              <Link href="/" className="flex items-center space-x-3 group">
                <Wheat className="h-10 w-10 text-green-600 transition-transform duration-300 group-hover:scale-110 group-hover:rotate-12" />
                <div>
                  <span className="text-2xl font-bold bg-gradient-to-r from-green-600 to-emerald-600 bg-clip-text text-transparent">
                    AgriAssist
                  </span>
                  <Badge variant="outline" className="ml-2 text-green-600 border-green-200">
                    Dashboard
                  </Badge>
                </div>
              </Link>
            </div>

            <div className="flex items-center space-x-4">
              <div className="text-right">
                <div className="text-sm font-medium text-gray-700">Welcome, {user.name}</div>
                <div className="text-xs text-gray-500">{currentTime.toLocaleString()}</div>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={handleLogout}
                className="hover:bg-red-50 hover:border-red-200 hover:text-red-600 transition-all duration-300"
              >
                <LogOut className="h-4 w-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {/* Enhanced Welcome Section */}
        <div className="mb-8 animate-in slide-in-from-top duration-1000">
          <div className="bg-gradient-to-r from-green-600 to-emerald-600 rounded-3xl p-8 text-white relative overflow-hidden">
            <div className="absolute inset-0 bg-black/10"></div>
            <div className="relative z-10">
              <h1 className="text-4xl font-bold mb-2">Welcome back, {user.name}! 🌾</h1>
              <p className="text-green-100 text-lg">Here's your personalized farming dashboard for today</p>
            </div>
            <div className="absolute -top-4 -right-4 w-32 h-32 bg-white/10 rounded-full"></div>
            <div className="absolute -bottom-8 -left-8 w-24 h-24 bg-white/5 rounded-full"></div>
          </div>
        </div>

        {/* Enhanced Alert Cards */}
        <div className="grid lg:grid-cols-2 gap-6 mb-8">
          <Card className="border-0 shadow-xl bg-gradient-to-br from-red-50 to-pink-50 hover:shadow-2xl transition-all duration-500 hover:scale-105 animate-in slide-in-from-left duration-1000">
            <CardHeader className="pb-3">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-red-100 rounded-xl">
                  <AlertTriangle className="h-6 w-6 text-red-600" />
                </div>
                <div className="flex-1">
                  <CardTitle className="text-red-800 text-xl">Weather Alert</CardTitle>
                  <Badge variant="destructive" className="mt-1">
                    High Priority
                  </Badge>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-red-700 font-semibold mb-2 text-lg">Heavy Rainfall Expected Tomorrow</p>
              <p className="text-red-600 mb-4">
                25-30mm rainfall predicted. Consider postponing field activities and ensure proper drainage.
              </p>
              <Button
                size="sm"
                variant="outline"
                className="border-red-300 text-red-700 hover:bg-red-100 transition-all duration-300"
                onClick={() => {
                  alert(
                    "Detailed weather information: Heavy rainfall of 25-30mm expected tomorrow. Recommended actions: 1) Ensure proper field drainage 2) Postpone harvesting activities 3) Cover stored grain 4) Check irrigation channels",
                  )
                }}
              >
                View Details
              </Button>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-xl bg-gradient-to-br from-blue-50 to-cyan-50 hover:shadow-2xl transition-all duration-500 hover:scale-105 animate-in slide-in-from-right duration-1000">
            <CardHeader className="pb-3">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-blue-100 rounded-xl">
                  <Lightbulb className="h-6 w-6 text-blue-600" />
                </div>
                <div className="flex-1">
                  <CardTitle className="text-blue-800 text-xl">Smart Tip</CardTitle>
                  <Badge variant="secondary" className="mt-1">
                    Recommended
                  </Badge>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-blue-700 font-semibold mb-2 text-lg">Optimal Sowing Window</p>
              <p className="text-blue-600 mb-4">
                Avoid sowing in next 3 days due to high soil moisture. Wait for better conditions.
              </p>
              <Button
                size="sm"
                variant="outline"
                className="border-blue-300 text-blue-700 hover:bg-blue-100 transition-all duration-300"
                onClick={() => {
                  alert(
                    "Smart Tip Details: Current soil moisture levels are high due to recent rainfall. Sowing during this period may lead to seed rot and poor germination. Wait for 2-3 days for optimal soil conditions.",
                  )
                }}
              >
                Learn More
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Enhanced Main Dashboard Grid */}
        <div className="grid lg:grid-cols-3 gap-6 mb-8">
          {/* Enhanced Weather Card */}
          <Card className="border-0 shadow-xl hover:shadow-2xl transition-all duration-500 hover:scale-105 bg-gradient-to-br from-yellow-50 to-orange-50 animate-in slide-in-from-bottom duration-1000">
            <CardHeader>
              <CardTitle className="flex items-center space-x-3">
                <div className="p-2 bg-yellow-100 rounded-xl">
                  <Sun className="h-6 w-6 text-yellow-600" />
                </div>
                <span className="text-xl">Today's Weather</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <span className="text-4xl font-bold text-orange-600">28°C</span>
                  <div className="text-right">
                    <div className="text-lg font-medium text-gray-700">Partly Cloudy</div>
                    <div className="text-sm text-gray-500">Feels like 31°C</div>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-4">
                  {[
                    { icon: Droplets, value: "65%", label: "Humidity", color: "text-blue-500" },
                    { icon: Wind, value: "12 km/h", label: "Wind", color: "text-gray-500" },
                    { icon: CloudRain, value: "30%", label: "Rain", color: "text-blue-500" },
                  ].map((item, index) => (
                    <div key={index} className="text-center p-3 bg-white/50 rounded-xl">
                      <item.icon className={`h-5 w-5 ${item.color} mx-auto mb-2`} />
                      <div className="font-semibold text-gray-800">{item.value}</div>
                      <div className="text-xs text-gray-600">{item.label}</div>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Enhanced Yield Prediction */}
          <Card className="border-0 shadow-xl hover:shadow-2xl transition-all duration-500 hover:scale-105 bg-gradient-to-br from-green-50 to-emerald-50 animate-in slide-in-from-bottom duration-1000 delay-200">
            <CardHeader>
              <CardTitle className="flex items-center space-x-3">
                <div className="p-2 bg-green-100 rounded-xl">
                  <TrendingUp className="h-6 w-6 text-green-600" />
                </div>
                <span className="text-xl">Yield Estimate</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div>
                  <div className="flex justify-between items-center mb-3">
                    <span className="font-medium text-gray-700">Wheat (Current Season)</span>
                    <span className="text-sm text-green-600 flex items-center font-semibold">
                      <ArrowUp className="h-4 w-4 mr-1" />
                      +12%
                    </span>
                  </div>
                  <div className="text-3xl font-bold text-green-600 mb-3">18 Quintals</div>
                  <Progress value={75} className="h-3 rounded-full" />
                  <div className="text-sm text-gray-500 mt-2">75% of expected yield</div>
                </div>

                <div className="pt-4 border-t border-gray-200">
                  <div className="text-sm text-gray-600 mb-1">Market Price Estimate</div>
                  <div className="text-2xl font-bold text-gray-800">₹2,200/quintal</div>
                  <div className="text-sm text-green-600 font-semibold">Expected profit: ₹39,600</div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Enhanced Crop Suggestion */}
          <Card className="border-0 shadow-xl hover:shadow-2xl transition-all duration-500 hover:scale-105 bg-gradient-to-br from-amber-50 to-yellow-50 animate-in slide-in-from-bottom duration-1000 delay-400">
            <CardHeader>
              <CardTitle className="flex items-center space-x-3">
                <div className="p-2 bg-amber-100 rounded-xl">
                  <Wheat className="h-6 w-6 text-amber-600" />
                </div>
                <span className="text-xl">Crop Suggestion</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div>
                  <div className="font-medium text-amber-700 mb-2">Recommended for Next Season</div>
                  <div className="text-2xl font-bold text-amber-800">Bajra (Pearl Millet)</div>
                  <div className="text-gray-600 mb-4">Better heat resistance and drought tolerance for your region</div>
                </div>

                <div className="space-y-3">
                  {[
                    { label: "Expected Yield:", value: "15-20 quintals" },
                    { label: "Market Price:", value: "₹2,500/quintal" },
                    { label: "Profit Margin:", value: "+25%", highlight: true },
                  ].map((item, index) => (
                    <div key={index} className="flex justify-between items-center">
                      <span className="text-gray-600">{item.label}</span>
                      <span className={`font-semibold ${item.highlight ? "text-green-600" : "text-gray-800"}`}>
                        {item.value}
                      </span>
                    </div>
                  ))}
                </div>

                <Link href="/planting-guide">
                  <Button className="w-full bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700 text-white rounded-xl transition-all duration-300 hover:scale-105">
                    View Planting Guide
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Enhanced Rainfall Trends Chart */}
        <Card className="mb-8 border-0 shadow-xl hover:shadow-2xl transition-all duration-500 bg-white/80 backdrop-blur-sm animate-in slide-in-from-bottom duration-1000 delay-600">
          <CardHeader>
            <CardTitle className="text-2xl flex items-center space-x-3">
              <div className="p-2 bg-blue-100 rounded-xl">
                <CloudRain className="h-6 w-6 text-blue-600" />
              </div>
              <span>Rainfall Trends (Last 10 Days)</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={rainfallData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e0e7ff" />
                  <XAxis dataKey="day" stroke="#6b7280" />
                  <YAxis stroke="#6b7280" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "rgba(255, 255, 255, 0.95)",
                      border: "none",
                      borderRadius: "12px",
                      boxShadow: "0 10px 25px rgba(0, 0, 0, 0.1)",
                    }}
                  />
                  <Line
                    type="monotone"
                    dataKey="rainfall"
                    stroke="#3B82F6"
                    strokeWidth={3}
                    dot={{ fill: "#3B82F6", strokeWidth: 2, r: 6 }}
                    activeDot={{ r: 8, stroke: "#3B82F6", strokeWidth: 2 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Enhanced Quick Actions */}
        <div className="grid md:grid-cols-4 gap-6 animate-in slide-in-from-bottom duration-1000 delay-800">
          {[
            { href: "/planting-guide", icon: Wheat, label: "Planting Guide", color: "from-green-500 to-emerald-500" },
            {
              href: "/knowledge-assistant",
              icon: Lightbulb,
              label: "Ask Assistant",
              color: "from-blue-500 to-cyan-500",
            },
            {
              href: "/climate-advisory",
              icon: TrendingUp,
              label: "Climate Advisory",
              color: "from-purple-500 to-pink-500",
            },
            { href: "/settings", icon: User, label: "Settings", color: "from-orange-500 to-red-500" },
          ].map((action, index) => (
            <Link key={index} href={action.href}>
              <Card className="group border-0 shadow-lg hover:shadow-2xl transition-all duration-500 hover:scale-105 hover:-translate-y-2 cursor-pointer bg-gradient-to-br from-white to-gray-50">
                <CardContent className="p-6 text-center relative overflow-hidden">
                  <div className="absolute inset-0 bg-gradient-to-br from-white/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                  <div
                    className={`relative inline-block p-4 rounded-2xl bg-gradient-to-br ${action.color} mb-4 group-hover:scale-110 transition-transform duration-300 shadow-lg`}
                  >
                    <action.icon className="h-8 w-8 text-white" />
                  </div>
                  <div className="font-semibold text-gray-800 group-hover:text-gray-900 transition-colors duration-300">
                    {action.label}
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </main>
    </div>
  )
}
