"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  TrendingUp,
  ArrowLeft,
  Download,
  Thermometer,
  CloudRain,
  Wind,
  AlertTriangle,
  CheckCircle,
  BarChart3,
  Calendar,
} from "lucide-react"
import Link from "next/link"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"

const climateData = [
  { year: "2019", temperature: 26.5, rainfall: 850 },
  { year: "2020", temperature: 27.2, rainfall: 780 },
  { year: "2021", temperature: 27.8, rainfall: 920 },
  { year: "2022", temperature: 28.1, rainfall: 650 },
  { year: "2023", temperature: 28.5, rainfall: 720 },
  { year: "2024", temperature: 29.0, rainfall: 680 },
]

const cropRotationPlan = [
  { season: "Kharif 2024", crop: "Cotton", status: "completed", yield: "12 quintals" },
  { season: "Rabi 2024-25", crop: "Wheat", status: "current", yield: "Expected: 18 quintals" },
  { season: "Kharif 2025", crop: "Bajra", status: "planned", yield: "Expected: 15 quintals" },
  { season: "Rabi 2025-26", crop: "Mustard", status: "planned", yield: "Expected: 8 quintals" },
]

const marketPrices = [
  { crop: "Wheat", currentPrice: 2200, projectedPrice: 2400, change: "+9%" },
  { crop: "Cotton", currentPrice: 6800, projectedPrice: 7200, change: "+6%" },
  { crop: "Bajra", currentPrice: 2500, projectedPrice: 2650, change: "+6%" },
  { crop: "Mustard", currentPrice: 5200, projectedPrice: 5500, change: "+6%" },
]

export default function ClimateAdvisory() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Link href="/dashboard">
                <Button variant="ghost" size="sm">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Back to Dashboard
                </Button>
              </Link>
              <div className="flex items-center space-x-2">
                <TrendingUp className="h-6 w-6 text-purple-600" />
                <h1 className="text-2xl font-bold text-purple-800">Climate Advisory</h1>
              </div>
            </div>
            <Button className="bg-purple-600 hover:bg-purple-700">
              <Download className="h-4 w-4 mr-2" />
              Download Report
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {/* Climate Overview */}
        <div className="grid lg:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Thermometer className="h-5 w-5 text-red-500" />
                <span>Temperature Trend</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <div className="text-2xl font-bold text-red-600">+2.5°C</div>
                  <div className="text-sm text-gray-600">Average increase over 5 years</div>
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Current Year</span>
                    <span className="font-medium">29.0°C</span>
                  </div>
                  <Progress value={85} className="h-2" />
                  <div className="text-xs text-gray-500">Above normal by 15%</div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <CloudRain className="h-5 w-5 text-blue-500" />
                <span>Rainfall Pattern</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <div className="text-2xl font-bold text-blue-600">680mm</div>
                  <div className="text-sm text-gray-600">Annual rainfall (2024)</div>
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>vs Normal</span>
                    <span className="font-medium text-red-600">-20%</span>
                  </div>
                  <Progress value={60} className="h-2" />
                  <div className="text-xs text-gray-500">Below average</div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Wind className="h-5 w-5 text-gray-500" />
                <span>Risk Assessment</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center space-x-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-500" />
                  <span className="font-medium">Moderate Risk</span>
                </div>
                <div className="space-y-2 text-sm">
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                    <span>Heat stress likely</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-yellow-500 rounded-full"></div>
                    <span>Water scarcity risk</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    <span>Pest pressure normal</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Climate Trends Chart */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>5-Year Climate Trends</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={climateData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="year" />
                  <YAxis yAxisId="temp" orientation="left" />
                  <YAxis yAxisId="rain" orientation="right" />
                  <Tooltip />
                  <Line
                    yAxisId="temp"
                    type="monotone"
                    dataKey="temperature"
                    stroke="#EF4444"
                    strokeWidth={2}
                    name="Temperature (°C)"
                  />
                  <Line
                    yAxisId="rain"
                    type="monotone"
                    dataKey="rainfall"
                    stroke="#3B82F6"
                    strokeWidth={2}
                    name="Rainfall (mm)"
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Crop Rotation Strategy */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Calendar className="h-5 w-5 text-green-600" />
              <span>Suggested Crop Rotation Strategy</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {cropRotationPlan.map((plan, index) => (
                <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex items-center space-x-4">
                    <div className="flex items-center space-x-2">
                      {plan.status === "completed" && <CheckCircle className="h-5 w-5 text-green-500" />}
                      {plan.status === "current" && (
                        <div className="h-5 w-5 bg-blue-500 rounded-full animate-pulse"></div>
                      )}
                      {plan.status === "planned" && (
                        <div className="h-5 w-5 border-2 border-gray-300 rounded-full"></div>
                      )}
                    </div>
                    <div>
                      <div className="font-medium">{plan.season}</div>
                      <div className="text-sm text-gray-600">{plan.crop}</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-medium">{plan.yield}</div>
                    <Badge
                      variant={
                        plan.status === "completed" ? "default" : plan.status === "current" ? "secondary" : "outline"
                      }
                    >
                      {plan.status}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Market Price Projections */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <BarChart3 className="h-5 w-5 text-green-600" />
              <span>Projected Market Prices</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b">
                    <th className="text-left py-3 px-4">Crop</th>
                    <th className="text-left py-3 px-4">Current Price (₹/quintal)</th>
                    <th className="text-left py-3 px-4">Projected Price (₹/quintal)</th>
                    <th className="text-left py-3 px-4">Expected Change</th>
                  </tr>
                </thead>
                <tbody>
                  {marketPrices.map((price, index) => (
                    <tr key={index} className="border-b">
                      <td className="py-3 px-4 font-medium">{price.crop}</td>
                      <td className="py-3 px-4">₹{price.currentPrice.toLocaleString()}</td>
                      <td className="py-3 px-4">₹{price.projectedPrice.toLocaleString()}</td>
                      <td className="py-3 px-4">
                        <Badge variant="secondary" className="text-green-600">
                          {price.change}
                        </Badge>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        {/* Adaptation Recommendations */}
        <Card>
          <CardHeader>
            <CardTitle>Climate Adaptation Recommendations</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h3 className="font-semibold mb-3 text-green-800">Short-term Actions (Next 6 months)</h3>
                <div className="space-y-3">
                  <div className="flex items-start space-x-3">
                    <CheckCircle className="h-5 w-5 text-green-500 mt-0.5" />
                    <div>
                      <div className="font-medium">Water Conservation</div>
                      <div className="text-sm text-gray-600">Install drip irrigation and mulching</div>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <CheckCircle className="h-5 w-5 text-green-500 mt-0.5" />
                    <div>
                      <div className="font-medium">Heat-Resistant Varieties</div>
                      <div className="text-sm text-gray-600">Switch to drought-tolerant crop varieties</div>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <CheckCircle className="h-5 w-5 text-green-500 mt-0.5" />
                    <div>
                      <div className="font-medium">Soil Health</div>
                      <div className="text-sm text-gray-600">Increase organic matter content</div>
                    </div>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="font-semibold mb-3 text-blue-800">Long-term Strategy (1-3 years)</h3>
                <div className="space-y-3">
                  <div className="flex items-start space-x-3">
                    <CheckCircle className="h-5 w-5 text-blue-500 mt-0.5" />
                    <div>
                      <div className="font-medium">Crop Diversification</div>
                      <div className="text-sm text-gray-600">Introduce climate-resilient crops</div>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <CheckCircle className="h-5 w-5 text-blue-500 mt-0.5" />
                    <div>
                      <div className="font-medium">Infrastructure</div>
                      <div className="text-sm text-gray-600">Build water storage and shade structures</div>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <CheckCircle className="h-5 w-5 text-blue-500 mt-0.5" />
                    <div>
                      <div className="font-medium">Technology Adoption</div>
                      <div className="text-sm text-gray-600">Implement precision agriculture tools</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
