"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Checkbox } from "@/components/ui/checkbox"
import { Wheat, User, Phone, MapPin, Globe, Eye, EyeOff, ArrowLeft, Sparkles, Shield, CheckCircle } from "lucide-react"
import { useRouter } from "next/navigation"
import Link from "next/link"

const languages = [
  { code: "en", name: "English" },
  { code: "hi", name: "हिंदी (Hindi)" },
  { code: "ur", name: "اردو (Urdu)" },
  { code: "bho", name: "भोजपुरी (Bhojpuri)" },
  { code: "awa", name: "अवधी (Awadhi)" },
  { code: "bun", name: "बुंदेली (Bundeli)" },
  { code: "bn", name: "বাংলা (Bengali)" },
  { code: "gu", name: "ગુજરાતી (Gujarati)" },
  { code: "kn", name: "ಕನ್ನಡ (Kannada)" },
  { code: "ml", name: "മലയാളം (Malayalam)" },
  { code: "mr", name: "मराठी (Marathi)" },
  { code: "or", name: "ଓଡ଼ିଆ (Odia)" },
  { code: "pa", name: "ਪੰਜਾਬੀ (Punjabi)" },
  { code: "ta", name: "தமிழ் (Tamil)" },
  { code: "te", name: "తెలుగు (Telugu)" },
]

const states = [
  "Andhra Pradesh",
  "Arunachal Pradesh",
  "Assam",
  "Bihar",
  "Chhattisgarh",
  "Goa",
  "Gujarat",
  "Haryana",
  "Himachal Pradesh",
  "Jharkhand",
  "Karnataka",
  "Kerala",
  "Madhya Pradesh",
  "Maharashtra",
  "Manipur",
  "Meghalaya",
  "Mizoram",
  "Nagaland",
  "Odisha",
  "Punjab",
  "Rajasthan",
  "Sikkim",
  "Tamil Nadu",
  "Telangana",
  "Tripura",
  "Uttar Pradesh",
  "Uttarakhand",
  "West Bengal",
]

const districtsByState: { [key: string]: string[] } = {
  "Uttar Pradesh": ["Agra", "Allahabad", "Bareilly", "Ghaziabad", "Kanpur", "Lucknow", "Meerut", "Varanasi"],
  Gujarat: ["Ahmedabad", "Rajkot", "Surat", "Vadodara", "Bhavnagar", "Jamnagar"],
  Karnataka: ["Bangalore", "Mysore", "Hubli", "Mangalore", "Belgaum", "Gulbarga"],
  "Tamil Nadu": ["Chennai", "Coimbatore", "Madurai", "Tiruchirappalli", "Salem", "Tirunelveli"],
  Telangana: ["Hyderabad", "Warangal", "Nizamabad", "Karimnagar", "Khammam"],
  Maharashtra: ["Mumbai", "Pune", "Nagpur", "Nashik", "Aurangabad", "Solapur"],
  Punjab: ["Ludhiana", "Amritsar", "Jalandhar", "Patiala", "Bathinda", "Mohali"],
  Haryana: ["Gurgaon", "Faridabad", "Panipat", "Ambala", "Yamunanagar", "Rohtak"],
}

const crops = [
  "Wheat",
  "Rice",
  "Cotton",
  "Sugarcane",
  "Bajra",
  "Jowar",
  "Maize",
  "Mustard",
  "Groundnut",
  "Soybean",
  "Chickpea",
  "Pigeon Pea",
  "Tomato",
  "Onion",
  "Potato",
]

const farmSizes = ["Less than 1 acre", "1-2 acres", "2-5 acres", "5-10 acres", "10-25 acres", "More than 25 acres"]

export default function AuthPage() {
  const router = useRouter()
  const [activeTab, setActiveTab] = useState("login")
  const [showPassword, setShowPassword] = useState(false)
  const [isLoading, setIsLoading] = useState(false)

  // Login form state
  const [loginData, setLoginData] = useState({
    phone: "",
    password: "",
  })

  // Signup form state
  const [signupData, setSignupData] = useState({
    fullName: "",
    phone: "",
    email: "",
    password: "",
    confirmPassword: "",
    language: "en",
    state: "",
    district: "",
    primaryCrop: "",
    farmSize: "",
    experience: "",
    agreeToTerms: false,
  })

  // Default login credentials
  const defaultCredentials = {
    phone: "9876543210",
    password: "farmer123",
  }

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    // Simulate API call
    setTimeout(() => {
      if (loginData.phone === defaultCredentials.phone && loginData.password === defaultCredentials.password) {
        localStorage.setItem(
          "agriAssistUser",
          JSON.stringify({
            phone: loginData.phone,
            name: "Ramesh Kumar",
            isLoggedIn: true,
          }),
        )
        router.push("/dashboard")
      } else {
        alert("Invalid credentials. Use phone: 9876543210, password: farmer123")
      }
      setIsLoading(false)
    }, 1500)
  }

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault()

    if (signupData.password !== signupData.confirmPassword) {
      alert("Passwords do not match")
      return
    }

    if (!signupData.agreeToTerms) {
      alert("Please agree to terms and conditions")
      return
    }

    setIsLoading(true)

    // Simulate API call
    setTimeout(() => {
      localStorage.setItem(
        "agriAssistUser",
        JSON.stringify({
          phone: signupData.phone,
          name: signupData.fullName,
          isLoggedIn: true,
          profile: signupData,
        }),
      )
      router.push("/dashboard")
    }, 2000)
  }

  const availableDistricts = signupData.state ? districtsByState[signupData.state] || [] : []

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-emerald-50 to-teal-100 relative overflow-hidden">
      {/* Animated Background Elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-green-200 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob"></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-emerald-200 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob animation-delay-2000"></div>
        <div className="absolute top-40 left-40 w-80 h-80 bg-teal-200 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob animation-delay-4000"></div>
      </div>

      {/* Back Button */}
      <div className="absolute top-6 left-6 z-20">
        <Link href="/">
          <Button
            variant="ghost"
            size="sm"
            className="backdrop-blur-sm bg-white/30 hover:bg-white/50 border border-white/20 rounded-xl"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Home
          </Button>
        </Link>
      </div>

      <div className="min-h-screen flex items-center justify-center p-4 relative z-10">
        <div className="w-full max-w-md animate-in slide-in-from-bottom-10 duration-1000">
          {/* Header */}
          <div className="text-center mb-8">
            <div className="flex items-center justify-center space-x-3 mb-6 group">
              <div className="relative">
                <Wheat className="h-12 w-12 text-green-600 transition-transform duration-300 group-hover:scale-110 group-hover:rotate-12" />
                <Sparkles className="absolute -top-1 -right-1 h-4 w-4 text-yellow-400 animate-pulse" />
              </div>
              <span className="text-4xl font-bold bg-gradient-to-r from-green-600 to-emerald-600 bg-clip-text text-transparent">
                AgriAssist
              </span>
            </div>
            <p className="text-green-700 text-lg font-medium">Empowering farmers with AI insights</p>
          </div>

          <Card className="shadow-2xl border-0 backdrop-blur-lg bg-white/80 rounded-3xl overflow-hidden">
            <CardHeader className="pb-0">
              <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                <TabsList className="grid w-full grid-cols-2 bg-gray-100/50 rounded-2xl p-1">
                  <TabsTrigger
                    value="login"
                    className="rounded-xl data-[state=active]:bg-white data-[state=active]:shadow-lg transition-all duration-300"
                  >
                    <Shield className="h-4 w-4 mr-2" />
                    Login
                  </TabsTrigger>
                  <TabsTrigger
                    value="signup"
                    className="rounded-xl data-[state=active]:bg-white data-[state=active]:shadow-lg transition-all duration-300"
                  >
                    <User className="h-4 w-4 mr-2" />
                    Sign Up
                  </TabsTrigger>
                </TabsList>
              </Tabs>
            </CardHeader>

            <CardContent className="p-8">
              <Tabs value={activeTab} onValueChange={setActiveTab}>
                {/* Login Tab */}
                <TabsContent value="login" className="space-y-6 animate-in fade-in-50 duration-500">
                  <form onSubmit={handleLogin} className="space-y-6">
                    <div className="space-y-2">
                      <Label htmlFor="login-phone" className="text-gray-700 font-medium">
                        Phone Number
                      </Label>
                      <div className="relative group">
                        <Phone className="absolute left-3 top-3 h-5 w-5 text-gray-400 group-focus-within:text-green-600 transition-colors duration-300" />
                        <Input
                          id="login-phone"
                          type="tel"
                          placeholder="Enter your phone number"
                          className="pl-12 h-12 rounded-xl border-gray-200 focus:border-green-500 focus:ring-green-500 transition-all duration-300"
                          value={loginData.phone}
                          onChange={(e) => setLoginData({ ...loginData, phone: e.target.value })}
                          required
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="login-password" className="text-gray-700 font-medium">
                        Password
                      </Label>
                      <div className="relative group">
                        <Input
                          id="login-password"
                          type={showPassword ? "text" : "password"}
                          placeholder="Enter your password"
                          className="h-12 rounded-xl border-gray-200 focus:border-green-500 focus:ring-green-500 transition-all duration-300 pr-12"
                          value={loginData.password}
                          onChange={(e) => setLoginData({ ...loginData, password: e.target.value })}
                          required
                        />
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                          onClick={() => setShowPassword(!showPassword)}
                        >
                          {showPassword ? (
                            <EyeOff className="h-5 w-5 text-gray-400" />
                          ) : (
                            <Eye className="h-5 w-5 text-gray-400" />
                          )}
                        </Button>
                      </div>
                    </div>

                    <Button
                      type="submit"
                      className="w-full h-12 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white rounded-xl font-medium transition-all duration-300 hover:scale-105 hover:shadow-lg"
                      disabled={isLoading}
                    >
                      {isLoading ? (
                        <>
                          <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                          Logging in...
                        </>
                      ) : (
                        <>
                          <Shield className="h-5 w-5 mr-2" />
                          Login to Dashboard
                        </>
                      )}
                    </Button>

                    {/* Default credentials info */}
                    <div className="p-4 bg-gradient-to-r from-blue-50 to-cyan-50 rounded-xl border border-blue-200">
                      <div className="flex items-center mb-2">
                        <CheckCircle className="h-5 w-5 text-blue-600 mr-2" />
                        <p className="text-sm text-blue-800 font-semibold">Demo Credentials:</p>
                      </div>
                      <div className="space-y-1 text-sm text-blue-700">
                        <p>
                          <span className="font-medium">Phone:</span> 9876543210
                        </p>
                        <p>
                          <span className="font-medium">Password:</span> farmer123
                        </p>
                      </div>
                    </div>

                    <div className="text-center">
                      <Button variant="link" className="text-green-600 hover:text-green-700 font-medium">
                        Forgot Password?
                      </Button>
                    </div>
                  </form>
                </TabsContent>

                {/* Signup Tab */}
                <TabsContent value="signup" className="space-y-6 animate-in fade-in-50 duration-500">
                  <form onSubmit={handleSignup} className="space-y-6">
                    {/* Personal Information */}
                    <div className="space-y-4">
                      <div className="flex items-center space-x-2 text-sm font-semibold text-gray-700 border-b border-gray-200 pb-2">
                        <User className="h-4 w-4 text-green-600" />
                        <span>Personal Information</span>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="fullName" className="text-gray-700 font-medium">
                          Full Name *
                        </Label>
                        <Input
                          id="fullName"
                          placeholder="Enter your full name"
                          className="h-12 rounded-xl border-gray-200 focus:border-green-500 focus:ring-green-500 transition-all duration-300"
                          value={signupData.fullName}
                          onChange={(e) => setSignupData({ ...signupData, fullName: e.target.value })}
                          required
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="signup-phone" className="text-gray-700 font-medium">
                          Phone Number *
                        </Label>
                        <div className="relative group">
                          <Phone className="absolute left-3 top-3 h-5 w-5 text-gray-400 group-focus-within:text-green-600 transition-colors duration-300" />
                          <Input
                            id="signup-phone"
                            type="tel"
                            placeholder="Enter your phone number"
                            className="pl-12 h-12 rounded-xl border-gray-200 focus:border-green-500 focus:ring-green-500 transition-all duration-300"
                            value={signupData.phone}
                            onChange={(e) => setSignupData({ ...signupData, phone: e.target.value })}
                            required
                          />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="email" className="text-gray-700 font-medium">
                          Email (Optional)
                        </Label>
                        <Input
                          id="email"
                          type="email"
                          placeholder="Enter your email"
                          className="h-12 rounded-xl border-gray-200 focus:border-green-500 focus:ring-green-500 transition-all duration-300"
                          value={signupData.email}
                          onChange={(e) => setSignupData({ ...signupData, email: e.target.value })}
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="signup-password" className="text-gray-700 font-medium">
                            Password *
                          </Label>
                          <Input
                            id="signup-password"
                            type="password"
                            placeholder="Create password"
                            className="h-12 rounded-xl border-gray-200 focus:border-green-500 focus:ring-green-500 transition-all duration-300"
                            value={signupData.password}
                            onChange={(e) => setSignupData({ ...signupData, password: e.target.value })}
                            required
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="confirmPassword" className="text-gray-700 font-medium">
                            Confirm Password *
                          </Label>
                          <Input
                            id="confirmPassword"
                            type="password"
                            placeholder="Confirm password"
                            className="h-12 rounded-xl border-gray-200 focus:border-green-500 focus:ring-green-500 transition-all duration-300"
                            value={signupData.confirmPassword}
                            onChange={(e) => setSignupData({ ...signupData, confirmPassword: e.target.value })}
                            required
                          />
                        </div>
                      </div>
                    </div>

                    {/* Location Information */}
                    <div className="space-y-4">
                      <div className="flex items-center space-x-2 text-sm font-semibold text-gray-700 border-b border-gray-200 pb-2">
                        <MapPin className="h-4 w-4 text-green-600" />
                        <span>Location & Preferences</span>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="language" className="text-gray-700 font-medium">
                          Preferred Language *
                        </Label>
                        <div className="relative group">
                          <Globe className="absolute left-3 top-3 h-5 w-5 text-gray-400 group-focus-within:text-green-600 transition-colors duration-300 z-10" />
                          <Select
                            value={signupData.language}
                            onValueChange={(value) => setSignupData({ ...signupData, language: value })}
                          >
                            <SelectTrigger className="pl-12 h-12 rounded-xl border-gray-200 focus:border-green-500 focus:ring-green-500 transition-all duration-300">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent className="rounded-xl">
                              {languages.map((lang) => (
                                <SelectItem key={lang.code} value={lang.code} className="rounded-lg">
                                  {lang.name}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="state" className="text-gray-700 font-medium">
                            State *
                          </Label>
                          <Select
                            value={signupData.state}
                            onValueChange={(value) => setSignupData({ ...signupData, state: value, district: "" })}
                          >
                            <SelectTrigger className="h-12 rounded-xl border-gray-200 focus:border-green-500 focus:ring-green-500 transition-all duration-300">
                              <SelectValue placeholder="Select state" />
                            </SelectTrigger>
                            <SelectContent className="rounded-xl max-h-60">
                              {states.map((state) => (
                                <SelectItem key={state} value={state} className="rounded-lg">
                                  {state}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="district" className="text-gray-700 font-medium">
                            District *
                          </Label>
                          <Select
                            value={signupData.district}
                            onValueChange={(value) => setSignupData({ ...signupData, district: value })}
                            disabled={!signupData.state}
                          >
                            <SelectTrigger className="h-12 rounded-xl border-gray-200 focus:border-green-500 focus:ring-green-500 transition-all duration-300">
                              <SelectValue placeholder="Select district" />
                            </SelectTrigger>
                            <SelectContent className="rounded-xl">
                              {availableDistricts.map((district) => (
                                <SelectItem key={district} value={district} className="rounded-lg">
                                  {district}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="primaryCrop" className="text-gray-700 font-medium">
                            Primary Crop *
                          </Label>
                          <Select
                            value={signupData.primaryCrop}
                            onValueChange={(value) => setSignupData({ ...signupData, primaryCrop: value })}
                          >
                            <SelectTrigger className="h-12 rounded-xl border-gray-200 focus:border-green-500 focus:ring-green-500 transition-all duration-300">
                              <SelectValue placeholder="Select crop" />
                            </SelectTrigger>
                            <SelectContent className="rounded-xl">
                              {crops.map((crop) => (
                                <SelectItem key={crop} value={crop.toLowerCase()} className="rounded-lg">
                                  {crop}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="farmSize" className="text-gray-700 font-medium">
                            Farm Size *
                          </Label>
                          <Select
                            value={signupData.farmSize}
                            onValueChange={(value) => setSignupData({ ...signupData, farmSize: value })}
                          >
                            <SelectTrigger className="h-12 rounded-xl border-gray-200 focus:border-green-500 focus:ring-green-500 transition-all duration-300">
                              <SelectValue placeholder="Select size" />
                            </SelectTrigger>
                            <SelectContent className="rounded-xl">
                              {farmSizes.map((size) => (
                                <SelectItem key={size} value={size} className="rounded-lg">
                                  {size}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="experience" className="text-gray-700 font-medium">
                          Farming Experience
                        </Label>
                        <Select
                          value={signupData.experience}
                          onValueChange={(value) => setSignupData({ ...signupData, experience: value })}
                        >
                          <SelectTrigger className="h-12 rounded-xl border-gray-200 focus:border-green-500 focus:ring-green-500 transition-all duration-300">
                            <SelectValue placeholder="Select experience" />
                          </SelectTrigger>
                          <SelectContent className="rounded-xl">
                            <SelectItem value="beginner" className="rounded-lg">
                              Beginner (0-2 years)
                            </SelectItem>
                            <SelectItem value="intermediate" className="rounded-lg">
                              Intermediate (3-10 years)
                            </SelectItem>
                            <SelectItem value="experienced" className="rounded-lg">
                              Experienced (10+ years)
                            </SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    {/* Terms and Conditions */}
                    <div className="flex items-start space-x-3 p-4 bg-gray-50 rounded-xl">
                      <Checkbox
                        id="terms"
                        checked={signupData.agreeToTerms}
                        onCheckedChange={(checked) =>
                          setSignupData({ ...signupData, agreeToTerms: checked as boolean })
                        }
                        className="mt-1"
                      />
                      <Label htmlFor="terms" className="text-sm text-gray-700 leading-relaxed">
                        I agree to the{" "}
                        <Button variant="link" className="p-0 h-auto text-green-600 font-medium">
                          Terms and Conditions
                        </Button>{" "}
                        and{" "}
                        <Button variant="link" className="p-0 h-auto text-green-600 font-medium">
                          Privacy Policy
                        </Button>
                      </Label>
                    </div>

                    <Button
                      type="submit"
                      className="w-full h-12 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white rounded-xl font-medium transition-all duration-300 hover:scale-105 hover:shadow-lg"
                      disabled={isLoading}
                    >
                      {isLoading ? (
                        <>
                          <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                          Creating Account...
                        </>
                      ) : (
                        <>
                          <User className="h-5 w-5 mr-2" />
                          Create Account
                        </>
                      )}
                    </Button>
                  </form>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>

          {/* Footer */}
          <div className="text-center mt-8 space-y-2">
            <p className="text-sm text-green-700 font-medium">Need help? Contact us at support@agriassist.com</p>
            <p className="text-sm text-green-600">Or call: 1800-XXX-XXXX (Toll Free)</p>
          </div>
        </div>
      </div>

      <style jsx>{`
        @keyframes blob {
          0% {
            transform: translate(0px, 0px) scale(1);
          }
          33% {
            transform: translate(30px, -50px) scale(1.1);
          }
          66% {
            transform: translate(-20px, 20px) scale(0.9);
          }
          100% {
            transform: translate(0px, 0px) scale(1);
          }
        }
        .animate-blob {
          animation: blob 7s infinite;
        }
        .animation-delay-2000 {
          animation-delay: 2s;
        }
        .animation-delay-4000 {
          animation-delay: 4s;
        }
      `}</style>
    </div>
  )
}
