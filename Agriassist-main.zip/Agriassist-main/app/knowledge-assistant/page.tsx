"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { MessageCircle, Send, ArrowLeft, Bug, Droplets, CloudRain, Wheat, Lightbulb, BookOpen } from "lucide-react"
import Link from "next/link"

const categories = [
  { id: "disease", name: "Disease", icon: Bug, color: "bg-red-100 text-red-700" },
  { id: "fertilizer", name: "Fertilizer", icon: Droplets, color: "bg-blue-100 text-blue-700" },
  { id: "climate", name: "Climate", icon: CloudRain, color: "bg-green-100 text-green-700" },
  { id: "pest", name: "Pest", icon: Bug, color: "bg-orange-100 text-orange-700" },
  { id: "crop", name: "Crop", icon: Wheat, color: "bg-yellow-100 text-yellow-700" },
]

const sampleQuestions = [
  "What crop should I grow in July?",
  "How to treat wheat rust disease?",
  "Best fertilizer for cotton crop?",
  "When to harvest bajra?",
  "How to manage pest in tomato?",
]

const chatHistory = [
  {
    id: 1,
    question: "What is the best time to sow wheat?",
    answer:
      "The optimal time for wheat sowing is from mid-November to early December. This timing ensures the crop gets adequate cool weather during grain filling stage, which is crucial for good yield.",
    category: "crop",
    source: "ICAR Research Guidelines",
    timestamp: "2 hours ago",
  },
  {
    id: 2,
    question: "How to control aphids in mustard crop?",
    answer:
      "For aphid control in mustard: 1) Use neem oil spray (3-5ml per liter), 2) Apply imidacloprid 17.8% SL @ 0.3ml per liter, 3) Encourage natural predators like ladybird beetles. Monitor regularly and spray during early morning or evening.",
    category: "pest",
    source: "CRIDA Advisory",
    timestamp: "1 day ago",
  },
]

export default function KnowledgeAssistant() {
  const [question, setQuestion] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [messages, setMessages] = useState(chatHistory)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!question.trim()) return

    setIsLoading(true)

    // Simulate API call
    setTimeout(() => {
      const newMessage = {
        id: messages.length + 1,
        question: question,
        answer:
          "Based on your query, I recommend consulting with local agricultural experts and following integrated pest management practices. For specific crop recommendations, consider your soil type, local climate conditions, and market demand in your area.",
        category: selectedCategory || "general",
        source: "AgriAssist AI",
        timestamp: "Just now",
      }

      setMessages([newMessage, ...messages])
      setQuestion("")
      setSelectedCategory("")
      setIsLoading(false)
    }, 2000)
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center space-x-4">
            <Link href="/dashboard">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Dashboard
              </Button>
            </Link>
            <div className="flex items-center space-x-2">
              <MessageCircle className="h-6 w-6 text-blue-600" />
              <h1 className="text-2xl font-bold text-blue-800">Knowledge Assistant</h1>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Question Input Section */}
          <div className="lg:col-span-2">
            <Card className="mb-6">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Lightbulb className="h-5 w-5 text-yellow-500" />
                  <span>Ask Your Question</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">What would you like to know?</label>
                    <Textarea
                      id="question-input"
                      value={question}
                      onChange={(e) => setQuestion(e.target.value)}
                      placeholder="Type your farming question here..."
                      className="min-h-[100px]"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">Category (Optional)</label>
                    <div className="flex flex-wrap gap-2">
                      {categories.map((category) => {
                        const Icon = category.icon
                        return (
                          <Button
                            key={category.id}
                            type="button"
                            variant={selectedCategory === category.id ? "default" : "outline"}
                            size="sm"
                            onClick={() => setSelectedCategory(selectedCategory === category.id ? "" : category.id)}
                            className="flex items-center space-x-1"
                          >
                            <Icon className="h-4 w-4" />
                            <span>{category.name}</span>
                          </Button>
                        )
                      })}
                    </div>
                  </div>

                  <Button type="submit" disabled={!question.trim() || isLoading} className="w-full">
                    {isLoading ? (
                      <>
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                        Getting Answer...
                      </>
                    ) : (
                      <>
                        <Send className="h-4 w-4 mr-2" />
                        Ask Question
                      </>
                    )}
                  </Button>
                </form>
              </CardContent>
            </Card>

            {/* Chat History */}
            <div className="space-y-4">
              <h2 className="text-xl font-semibold">Recent Questions</h2>
              {messages.map((message) => (
                <Card key={message.id}>
                  <CardContent className="p-6">
                    <div className="space-y-4">
                      <div>
                        <div className="flex items-start justify-between mb-2">
                          <h3 className="font-medium text-gray-900">Q: {message.question}</h3>
                          <Badge variant="outline" className="ml-2">
                            {categories.find((c) => c.id === message.category)?.name || "General"}
                          </Badge>
                        </div>
                        <div className="text-sm text-gray-500 mb-3">{message.timestamp}</div>
                      </div>

                      <div className="bg-blue-50 p-4 rounded-lg">
                        <div className="font-medium text-blue-800 mb-2">Answer:</div>
                        <p className="text-blue-700">{message.answer}</p>
                      </div>

                      <div className="flex items-center justify-between text-sm text-gray-500">
                        <div className="flex items-center space-x-1">
                          <BookOpen className="h-4 w-4" />
                          <span>Source: {message.source}</span>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => {
                            alert(
                              `Detailed Information:\n\nQuestion: ${message.question}\n\nDetailed Answer: ${message.answer}\n\nSource: ${message.source}\n\nRecommended Actions:\n1. Consult local agricultural extension officer\n2. Monitor weather conditions regularly\n3. Follow integrated farming practices\n4. Keep records of farming activities`,
                            )
                          }}
                        >
                          Show Details
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Sample Questions */}
            <Card>
              <CardHeader>
                <CardTitle>Sample Questions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {sampleQuestions.map((q, index) => (
                    <Button
                      key={index}
                      variant="ghost"
                      size="sm"
                      className="w-full justify-start text-left h-auto p-3 hover:bg-gray-50"
                      onClick={() => {
                        setQuestion(q)
                        // Auto-focus on the textarea
                        document.getElementById("question-input")?.focus()
                      }}
                    >
                      {q}
                    </Button>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Categories */}
            <Card>
              <CardHeader>
                <CardTitle>Browse by Category</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {categories.map((category) => {
                    const Icon = category.icon
                    return (
                      <div
                        key={category.id}
                        className={`p-3 rounded-lg cursor-pointer hover:opacity-80 ${category.color}`}
                      >
                        <div className="flex items-center space-x-2">
                          <Icon className="h-5 w-5" />
                          <span className="font-medium">{category.name}</span>
                        </div>
                      </div>
                    )
                  })}
                </div>
              </CardContent>
            </Card>

            {/* Tips */}
            <Card>
              <CardHeader>
                <CardTitle>Tips for Better Answers</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 text-sm">
                  <div className="flex items-start space-x-2">
                    <div className="w-2 h-2 bg-green-500 rounded-full mt-2"></div>
                    <div>Be specific about your crop and location</div>
                  </div>
                  <div className="flex items-start space-x-2">
                    <div className="w-2 h-2 bg-green-500 rounded-full mt-2"></div>
                    <div>Include symptoms or current conditions</div>
                  </div>
                  <div className="flex items-start space-x-2">
                    <div className="w-2 h-2 bg-green-500 rounded-full mt-2"></div>
                    <div>Select appropriate category for faster response</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}
