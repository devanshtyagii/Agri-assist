"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Separator } from "@/components/ui/separator"
import { Settings, ArrowLeft, User, MapPin, Bell, Smartphone, Mail, Phone, Save } from "lucide-react"
import Link from "next/link"

const languages = [
  { code: "en", name: "English" },
  { code: "hi", name: "हिंदी (Hindi)" },
  { code: "ur", name: "اردو (Urdu)" },
  { code: "bho", name: "भोजपुरी (Bhojpuri)" },
  { code: "awa", name: "अवधी (Awadhi)" },
  { code: "bun", name: "बुंदेली (Bundeli)" },
  { code: "bn", name: "বাংলা (Bengali)" },
  { code: "gu", name: "ગુજરાતી (Gujarati)" },
  { code: "kn", name: "ಕನ್ನಡ (Kannada)" },
  { code: "ml", name: "മലയാളം (Malayalam)" },
  { code: "mr", name: "मराठी (Marathi)" },
  { code: "or", name: "ଓଡ଼ିଆ (Odia)" },
  { code: "pa", name: "ਪੰਜਾਬੀ (Punjabi)" },
  { code: "ta", name: "தமிழ் (Tamil)" },
  { code: "te", name: "తెలుగు (Telugu)" },
]

const districts = [
  "Agra",
  "Allahabad",
  "Bareilly",
  "Ghaziabad",
  "Kanpur",
  "Lucknow",
  "Meerut",
  "Varanasi",
  "Ahmedabad",
  "Rajkot",
  "Surat",
  "Vadodara",
  "Bangalore",
  "Mysore",
  "Chennai",
  "Coimbatore",
  "Hyderabad",
  "Visakhapatnam",
  "Mumbai",
  "Pune",
  "Nagpur",
  "Nashik",
]

const crops = [
  "Wheat",
  "Rice",
  "Cotton",
  "Sugarcane",
  "Bajra",
  "Jowar",
  "Maize",
  "Mustard",
  "Groundnut",
  "Soybean",
  "Chickpea",
  "Pigeon Pea",
  "Tomato",
  "Onion",
  "Potato",
]

export default function SettingsPage() {
  const [settings, setSettings] = useState({
    name: "Ramesh Kumar",
    phone: "+91 9876543210",
    email: "ramesh.kumar@email.com",
    language: "hi",
    district: "Agra",
    cropPreference: "wheat",
    smsAlerts: true,
    voiceAlerts: false,
    emailAlerts: true,
    weatherAlerts: true,
    cropAlerts: true,
    marketAlerts: false,
    pestAlerts: true,
  })

  const handleSave = () => {
    // Save settings to localStorage or API
    localStorage.setItem("agriAssistSettings", JSON.stringify(settings))
    alert("Settings saved successfully!")
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Link href="/dashboard">
                <Button variant="ghost" size="sm">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Back to Dashboard
                </Button>
              </Link>
              <div className="flex items-center space-x-2">
                <Settings className="h-6 w-6 text-gray-600" />
                <h1 className="text-2xl font-bold text-gray-800">Settings</h1>
              </div>
            </div>
            <Button onClick={handleSave} className="bg-green-600 hover:bg-green-700">
              <Save className="h-4 w-4 mr-2" />
              Save Changes
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto space-y-8">
          {/* Profile Information */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <User className="h-5 w-5 text-blue-600" />
                <span>Profile Information</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="name">Full Name</Label>
                  <Input
                    id="name"
                    value={settings.name}
                    onChange={(e) => setSettings({ ...settings, name: e.target.value })}
                    placeholder="Enter your full name"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="phone">Phone Number</Label>
                  <Input
                    id="phone"
                    value={settings.phone}
                    onChange={(e) => setSettings({ ...settings, phone: e.target.value })}
                    placeholder="+91 XXXXXXXXXX"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Email Address (Optional)</Label>
                <Input
                  id="email"
                  type="email"
                  value={settings.email}
                  onChange={(e) => setSettings({ ...settings, email: e.target.value })}
                  placeholder="your.email@example.com"
                />
              </div>
            </CardContent>
          </Card>

          {/* Location & Language */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <MapPin className="h-5 w-5 text-green-600" />
                <span>Location & Language</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="language">Preferred Language</Label>
                  <Select
                    value={settings.language}
                    onValueChange={(value) => setSettings({ ...settings, language: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {languages.map((lang) => (
                        <SelectItem key={lang.code} value={lang.code}>
                          {lang.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="district">District</Label>
                  <Select
                    value={settings.district}
                    onValueChange={(value) => setSettings({ ...settings, district: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {districts.map((district) => (
                        <SelectItem key={district} value={district.toLowerCase()}>
                          {district}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="crop">Primary Crop</Label>
                <Select
                  value={settings.cropPreference}
                  onValueChange={(value) => setSettings({ ...settings, cropPreference: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {crops.map((crop) => (
                      <SelectItem key={crop} value={crop.toLowerCase()}>
                        {crop}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Notification Preferences */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Bell className="h-5 w-5 text-orange-600" />
                <span>Notification Preferences</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <h3 className="font-medium mb-4">Alert Methods</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <Smartphone className="h-5 w-5 text-blue-600" />
                      <div>
                        <div className="font-medium">SMS Alerts</div>
                        <div className="text-sm text-gray-600">Receive alerts via text message</div>
                      </div>
                    </div>
                    <Switch
                      checked={settings.smsAlerts}
                      onCheckedChange={(checked) => setSettings({ ...settings, smsAlerts: checked })}
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <Phone className="h-5 w-5 text-green-600" />
                      <div>
                        <div className="font-medium">Voice Alerts</div>
                        <div className="text-sm text-gray-600">Receive voice calls for urgent alerts</div>
                      </div>
                    </div>
                    <Switch
                      checked={settings.voiceAlerts}
                      onCheckedChange={(checked) => setSettings({ ...settings, voiceAlerts: checked })}
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <Mail className="h-5 w-5 text-purple-600" />
                      <div>
                        <div className="font-medium">Email Alerts</div>
                        <div className="text-sm text-gray-600">Receive detailed reports via email</div>
                      </div>
                    </div>
                    <Switch
                      checked={settings.emailAlerts}
                      onCheckedChange={(checked) => setSettings({ ...settings, emailAlerts: checked })}
                    />
                  </div>
                </div>
              </div>

              <Separator />

              <div>
                <h3 className="font-medium mb-4">Alert Types</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-medium">Weather Alerts</div>
                      <div className="text-sm text-gray-600">Rain, temperature, and weather warnings</div>
                    </div>
                    <Switch
                      checked={settings.weatherAlerts}
                      onCheckedChange={(checked) => setSettings({ ...settings, weatherAlerts: checked })}
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-medium">Crop Recommendations</div>
                      <div className="text-sm text-gray-600">Sowing, harvesting, and crop care tips</div>
                    </div>
                    <Switch
                      checked={settings.cropAlerts}
                      onCheckedChange={(checked) => setSettings({ ...settings, cropAlerts: checked })}
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-medium">Market Price Updates</div>
                      <div className="text-sm text-gray-600">Current and projected market prices</div>
                    </div>
                    <Switch
                      checked={settings.marketAlerts}
                      onCheckedChange={(checked) => setSettings({ ...settings, marketAlerts: checked })}
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-medium">Pest & Disease Alerts</div>
                      <div className="text-sm text-gray-600">Early warnings for pest and disease outbreaks</div>
                    </div>
                    <Switch
                      checked={settings.pestAlerts}
                      onCheckedChange={(checked) => setSettings({ ...settings, pestAlerts: checked })}
                    />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* About */}
          <Card>
            <CardHeader>
              <CardTitle>About AgriAssist</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4 text-sm text-gray-600">
                <p>
                  AgriAssist is an AI-powered agricultural advisory system designed to empower farmers with real-time
                  insights, weather alerts, and crop recommendations.
                </p>
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <div className="font-medium text-gray-900">Version</div>
                    <div>1.0.0</div>
                  </div>
                  <div>
                    <div className="font-medium text-gray-900">Last Updated</div>
                    <div>December 2024</div>
                  </div>
                  <div>
                    <div className="font-medium text-gray-900">Support</div>
                    <div>support@agriassist.com</div>
                  </div>
                  <div>
                    <div className="font-medium text-gray-900">Helpline</div>
                    <div>1800-XXX-XXXX</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
