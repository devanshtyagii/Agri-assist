"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent } from "@/components/ui/card"
import { CloudRain, Wheat, TrendingUp, Globe, ArrowRight, Sparkles, Users, Award, Clock } from "lucide-react"
import { useRouter } from "next/navigation"

const languages = [
  { code: "en", name: "English" },
  { code: "hi", name: "हिंदी" },
  { code: "ur", name: "اردو" },
  { code: "bho", name: "भोजपुरी" },
  { code: "awa", name: "अवधी" },
  { code: "bun", name: "बुंदेली" },
]

const languageContent = {
  en: {
    title: "Empowering 23 Million Farmers with AI",
    subtitle:
      "Get real-time weather alerts, AI-powered crop recommendations, and climate-smart insights to maximize your harvest and protect your livelihood.",
    enterDashboard: "Enter My Dashboard",
    realTimeAlerts: "Real-time Alerts",
    realTimeAlertsDesc:
      "Get instant notifications about weather changes, pest outbreaks, and optimal farming conditions.",
    aiRecommendations: "AI Crop Recommendations",
    aiRecommendationsDesc:
      "Discover the best crops for your soil, climate, and market conditions using advanced AI analysis.",
    yieldPredictions: "Yield Predictions",
    yieldPredictionsDesc: "Plan better with accurate harvest predictions and market price forecasts for your crops.",
    readyToTransform: "Ready to Transform Your Farming?",
    joinMillions: "Join millions of farmers who trust AgriAssist for smarter agricultural decisions.",
    getStarted: "Get Started Now",
  },
  hi: {
    title: "AI के साथ 2.3 करोड़ किसानों को सशक्त बनाना",
    subtitle:
      "अपनी फसल को अधिकतम करने और अपनी आजीविका की रक्षा के लिए वास्तविक समय मौसम अलर्ट, AI-संचालित फसल सिफारिशें, और जलवायु-स्मार्ट अंतर्दृष्टि प्राप्त करें।",
    enterDashboard: "मेरा डैशबोर्ड दर्ज करें",
    realTimeAlerts: "वास्तविक समय अलर्ट",
    realTimeAlertsDesc: "मौसम परिवर्तन, कीट प्रकोप, और इष्टतम खेती की स्थितियों के बारे में तत्काल सूचनाएं प्राप्त करें।",
    aiRecommendations: "AI फसल सिफारिशें",
    aiRecommendationsDesc:
      "उन्नत AI विश्लेषण का उपयोग करके अपनी मिट्टी, जलवायु और बाजार की स्थितियों के लिए सर्वोत्तम फसलों की खोज करें।",
    yieldPredictions: "उपज भविष्यवाणी",
    yieldPredictionsDesc: "अपनी फसलों के लिए सटीक फसल भविष्यवाणी और बाजार मूल्य पूर्वानुमान के साथ बेहतर योजना बनाएं।",
    readyToTransform: "अपनी खेती को बदलने के लिए तैयार हैं?",
    joinMillions: "लाखों किसानों में शामिल हों जो स्मार्ट कृषि निर्णयों के लिए AgriAssist पर भरोसा करते हैं।",
    getStarted: "अभी शुरू करें",
  },
}

export default function HomePage() {
  const [selectedLanguage, setSelectedLanguage] = useState("en")
  const [content, setContent] = useState(languageContent.en)
  const [isVisible, setIsVisible] = useState(false)

  const handleLanguageChange = (langCode: string) => {
    setSelectedLanguage(langCode)
    setContent(languageContent[langCode as keyof typeof languageContent] || languageContent.en)
  }

  const router = useRouter()

  useEffect(() => {
    setIsVisible(true)
    const user = localStorage.getItem("agriAssistUser")
    if (user) {
      const userData = JSON.parse(user)
      if (userData.isLoggedIn) {
        return
      }
    }
  }, [])

  const handleEnterDashboard = () => {
    const user = localStorage.getItem("agriAssistUser")
    if (user) {
      const userData = JSON.parse(user)
      if (userData.isLoggedIn) {
        router.push("/dashboard")
        return
      }
    }
    router.push("/auth")
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-emerald-50 to-teal-100 relative overflow-hidden">
      {/* Animated Background Elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-green-200 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob"></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-emerald-200 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob animation-delay-2000"></div>
        <div className="absolute top-40 left-40 w-80 h-80 bg-teal-200 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob animation-delay-4000"></div>
      </div>

      {/* Header */}
      <header
        className={`container mx-auto px-4 py-6 relative z-10 transition-all duration-1000 ${isVisible ? "translate-y-0 opacity-100" : "-translate-y-10 opacity-0"}`}
      >
        <div className="flex justify-between items-center backdrop-blur-sm bg-white/30 rounded-2xl px-6 py-4 border border-white/20 shadow-lg">
          <div className="flex items-center space-x-3 group">
            <div className="relative">
              <Wheat className="h-10 w-10 text-green-600 transition-transform duration-300 group-hover:scale-110 group-hover:rotate-12" />
              <div className="absolute -top-1 -right-1 w-3 h-3 bg-yellow-400 rounded-full animate-pulse"></div>
            </div>
            <span className="text-3xl font-bold bg-gradient-to-r from-green-600 to-emerald-600 bg-clip-text text-transparent">
              AgriAssist
            </span>
          </div>
          <div className="flex items-center space-x-4">
            <Globe className="h-5 w-5 text-green-600 animate-pulse" />
            <Select value={selectedLanguage} onValueChange={handleLanguageChange}>
              <SelectTrigger className="w-36 bg-white/50 backdrop-blur-sm border-green-200 hover:bg-white/70 transition-all duration-300">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="backdrop-blur-md bg-white/90">
                {languages.map((lang) => (
                  <SelectItem key={lang.code} value={lang.code} className="hover:bg-green-50">
                    {lang.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <main className="container mx-auto px-4 py-12 relative z-10">
        <div
          className={`text-center mb-20 transition-all duration-1000 delay-300 ${isVisible ? "translate-y-0 opacity-100" : "translate-y-10 opacity-0"}`}
        >
          <div className="relative inline-block mb-6">
            <h1 className="text-6xl md:text-7xl font-bold bg-gradient-to-r from-green-600 via-emerald-600 to-teal-600 bg-clip-text text-transparent leading-tight">
              {content.title}
            </h1>
            <div className="absolute -top-4 -right-4">
              <Sparkles className="h-8 w-8 text-yellow-400 animate-spin" />
            </div>
          </div>
          <p className="text-xl md:text-2xl text-green-700 mb-10 max-w-3xl mx-auto leading-relaxed font-medium">
            {content.subtitle}
          </p>
          <div className="relative inline-block group">
            <Button
              size="lg"
              className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white px-10 py-6 text-xl rounded-2xl shadow-2xl transform transition-all duration-300 hover:scale-105 hover:shadow-green-500/25 group-hover:shadow-2xl"
              onClick={handleEnterDashboard}
            >
              <span className="relative z-10">{content.enterDashboard}</span>
              <ArrowRight className="ml-3 h-6 w-6 transition-transform duration-300 group-hover:translate-x-1" />
              <div className="absolute inset-0 bg-gradient-to-r from-green-400 to-emerald-400 rounded-2xl blur opacity-0 group-hover:opacity-50 transition-opacity duration-300"></div>
            </Button>
          </div>
        </div>

        {/* Feature Cards */}
        <div
          className={`grid md:grid-cols-3 gap-8 mb-20 transition-all duration-1000 delay-500 ${isVisible ? "translate-y-0 opacity-100" : "translate-y-10 opacity-0"}`}
        >
          {[
            {
              icon: CloudRain,
              title: content.realTimeAlerts,
              desc: content.realTimeAlertsDesc,
              color: "from-blue-500 to-cyan-500",
              bgColor: "bg-blue-50",
              delay: "delay-100",
            },
            {
              icon: Wheat,
              title: content.aiRecommendations,
              desc: content.aiRecommendationsDesc,
              color: "from-amber-500 to-orange-500",
              bgColor: "bg-amber-50",
              delay: "delay-200",
            },
            {
              icon: TrendingUp,
              title: content.yieldPredictions,
              desc: content.yieldPredictionsDesc,
              color: "from-green-500 to-emerald-500",
              bgColor: "bg-green-50",
              delay: "delay-300",
            },
          ].map((feature, index) => (
            <Card
              key={index}
              className={`group border-0 shadow-xl hover:shadow-2xl transition-all duration-500 hover:scale-105 hover:-translate-y-2 ${feature.bgColor} backdrop-blur-sm bg-white/60 ${feature.delay}`}
            >
              <CardContent className="p-8 text-center relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-white/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                <div
                  className={`relative inline-block p-4 rounded-2xl bg-gradient-to-br ${feature.color} mb-6 group-hover:scale-110 transition-transform duration-300`}
                >
                  <feature.icon className="h-12 w-12 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-gray-800 mb-4 group-hover:text-green-700 transition-colors duration-300">
                  {feature.title}
                </h3>
                <p className="text-gray-600 leading-relaxed group-hover:text-gray-700 transition-colors duration-300">
                  {feature.desc}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Enhanced Stats Section */}
        <div
          className={`relative mb-20 transition-all duration-1000 delay-700 ${isVisible ? "translate-y-0 opacity-100" : "translate-y-10 opacity-0"}`}
        >
          <div className="bg-gradient-to-r from-white/80 to-white/60 backdrop-blur-lg rounded-3xl shadow-2xl p-10 border border-white/20">
            <div className="grid md:grid-cols-4 gap-8 text-center">
              {[
                { number: "23M+", label: "Farmers Served", icon: Users, color: "text-green-600" },
                { number: "22", label: "Languages Supported", icon: Globe, color: "text-blue-600" },
                { number: "95%", label: "Accuracy Rate", icon: Award, color: "text-amber-600" },
                { number: "24/7", label: "Support Available", icon: Clock, color: "text-emerald-600" },
              ].map((stat, index) => (
                <div key={index} className="group">
                  <div
                    className={`inline-block p-3 rounded-2xl bg-gradient-to-br from-gray-100 to-gray-50 mb-4 group-hover:scale-110 transition-transform duration-300`}
                  >
                    <stat.icon className={`h-8 w-8 ${stat.color}`} />
                  </div>
                  <div
                    className={`text-4xl font-bold ${stat.color} mb-2 group-hover:scale-110 transition-transform duration-300`}
                  >
                    {stat.number}
                  </div>
                  <div className="text-gray-700 font-medium">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Enhanced CTA Section */}
        <div
          className={`text-center relative transition-all duration-1000 delay-900 ${isVisible ? "translate-y-0 opacity-100" : "translate-y-10 opacity-0"}`}
        >
          <div className="relative inline-block mb-6">
            <h2 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-green-600 to-emerald-600 bg-clip-text text-transparent">
              {content.readyToTransform}
            </h2>
          </div>
          <p className="text-xl text-green-700 mb-10 max-w-2xl mx-auto leading-relaxed">{content.joinMillions}</p>
          <div className="space-y-4 sm:space-y-0 sm:space-x-4 sm:flex sm:justify-center">
            <Button
              size="lg"
              variant="outline"
              className="border-2 border-green-600 text-green-600 hover:bg-green-600 hover:text-white px-8 py-4 text-lg rounded-2xl transition-all duration-300 hover:scale-105 hover:shadow-lg backdrop-blur-sm bg-white/50"
              onClick={() => router.push("/auth")}
            >
              {content.getStarted}
            </Button>
          </div>
        </div>
      </main>

      {/* Enhanced Footer */}
      <footer className="bg-gradient-to-r from-green-800 to-emerald-800 text-white py-12 mt-20 relative overflow-hidden">
        <div className="absolute inset-0 bg-black/10"></div>
        <div className="container mx-auto px-4 text-center relative z-10">
          <div className="flex items-center justify-center space-x-3 mb-6 group">
            <Wheat className="h-8 w-8 transition-transform duration-300 group-hover:scale-110 group-hover:rotate-12" />
            <span className="text-2xl font-bold">AgriAssist</span>
          </div>
          <p className="text-green-200 text-lg max-w-2xl mx-auto leading-relaxed">
            Empowering farmers with AI-driven insights for sustainable agriculture and prosperous farming communities
          </p>
          <div className="mt-8 flex justify-center space-x-6">
            <div className="text-sm text-green-300">
              <span className="font-semibold">Email:</span> support@agriassist.com
            </div>
            <div className="text-sm text-green-300">
              <span className="font-semibold">Helpline:</span> 1800-XXX-XXXX
            </div>
          </div>
        </div>
      </footer>

      <style jsx>{`
        @keyframes blob {
          0% {
            transform: translate(0px, 0px) scale(1);
          }
          33% {
            transform: translate(30px, -50px) scale(1.1);
          }
          66% {
            transform: translate(-20px, 20px) scale(0.9);
          }
          100% {
            transform: translate(0px, 0px) scale(1);
          }
        }
        .animate-blob {
          animation: blob 7s infinite;
        }
        .animation-delay-2000 {
          animation-delay: 2s;
        }
        .animation-delay-4000 {
          animation-delay: 4s;
        }
      `}</style>
    </div>
  )
}
