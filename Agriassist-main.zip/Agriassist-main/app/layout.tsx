import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "AgriAssist - Predictive Agricultural System",
  description:
    "Empowering farmers with AI-powered insights, weather alerts, and crop recommendations in 22+ Indian languages",
  keywords: "agriculture, farming, AI, weather alerts, crop recommendations, India, farmers",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={inter.className}>{children}</body>
    </html>
  )
}
